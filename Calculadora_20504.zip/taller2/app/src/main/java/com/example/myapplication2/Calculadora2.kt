package com.example.myapplication2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import android.widget.Button
import android.widget.TextView
import net.objecthunter.exp4j.Expression
import net.objecthunter.exp4j.ExpressionBuilder
import java.lang.Exception

class Calculadora2 : AppCompatActivity() {

    lateinit var txtResultado: TextView
    lateinit var txtExpr: TextView
    lateinit var btnUno: TextView
    lateinit var btndos: TextView
    lateinit var btntres: TextView
    lateinit var btncuatro: TextView
    lateinit var btncinco: TextView
    lateinit var btnseis: TextView
    lateinit var btnsiete: TextView
    lateinit var btnocho: TextView
    lateinit var btnnueve: TextView
    lateinit var btncero: TextView
    lateinit var btnmas: TextView
    lateinit var btnmenos: TextView
    lateinit var btndivision: TextView
    lateinit var btnpor: TextView
    lateinit var btnAC: TextView
    lateinit var btnparentiz: TextView
    lateinit var btnparentder: TextView
    lateinit var btnB: TextView
    lateinit var btnenter: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        txtResultado = findViewById(R.id.txtResult)
        txtExpr = findViewById(R.id.txtExpr)
        btnUno = findViewById(R.id.btnuno)
        btndos = findViewById(R.id.btndos)
        btntres = findViewById(R.id.btntres)
        btncuatro = findViewById(R.id.btncuatro)
        btncinco = findViewById(R.id.btncinco)
        btnseis = findViewById(R.id.btnseis)
        btnsiete = findViewById(R.id.btnsiete)
        btnocho = findViewById(R.id.btnocho)
        btnnueve = findViewById(R.id.btnnueve)
        btncero = findViewById(R.id.btncero)
        btnAC = findViewById(R.id.btnAC)
        btnmas = findViewById(R.id.btnmas)
        btnmenos = findViewById(R.id.btnmenos)
        btnpor = findViewById(R.id.btnpor)
        btndivision = findViewById(R.id.btndivision)
        btnparentiz = findViewById(R.id.btnparentiz)
        btnparentder = findViewById(R.id.btnparentder)
        btnB = findViewById(R.id.btnB)
        btnenter = findViewById(R.id.btnigual)

        //numeros
        btnUno.setOnClickListener{appendOnExpression("1",true)}
        btndos.setOnClickListener{appendOnExpression("2",true)}
        btntres.setOnClickListener{appendOnExpression("3",true)}
        btncuatro.setOnClickListener{appendOnExpression("4",true)}
        btncinco.setOnClickListener{appendOnExpression("5",true)}
        btnseis.setOnClickListener{appendOnExpression("6",true)}
        btnsiete.setOnClickListener{appendOnExpression("7",true)}
        btnocho.setOnClickListener{appendOnExpression("8",true)}
        btnnueve.setOnClickListener{appendOnExpression("9",true)}
        btncero.setOnClickListener{appendOnExpression("0",true)}

        //operadores
        btnmas.setOnClickListener{appendOnExpression("+",false)}
        btnmenos.setOnClickListener{appendOnExpression("-",false)}
        btnparentder.setOnClickListener{appendOnExpression(")",false)}
        btnparentiz.setOnClickListener{appendOnExpression("(",false)}
        btnpor.setOnClickListener{appendOnExpression("*",false)}
        btndivision.setOnClickListener{appendOnExpression("/",false)}

        btnAC.setOnClickListener {
            txtExpr.text = ""
            txtResultado.text=""

        }

        btnB.setOnClickListener{
            val String = txtExpr.text.toString()
            if (String.isNotEmpty()){
                txtExpr.text = String.substring(0,String.length-1)
            }
            txtResultado.text = ""
        }

        btnenter.setOnClickListener{
            try {
                val expression = ExpressionBuilder(txtExpr.text.toString()).build()
                val resultado = expression.evaluate()
                val longResult = resultado.toLong()
                if (resultado == longResult.toDouble()){
                    txtResultado.text = longResult.toString()
                }
                else{
                    txtResultado.text = resultado.toString()
                }
            }
            catch (e:Exception){
                Log.d("Exception","message: "+ e.message)
            }
        }

    }

    fun appendOnExpression (string:String, onClear:Boolean){
        if (onClear){
            txtResultado.text = ""
            txtExpr.append(string)
        }
        else{
            txtExpr.append(txtResultado.text)
            txtExpr.append(string)
            txtResultado.text = ""
        }
    }
}